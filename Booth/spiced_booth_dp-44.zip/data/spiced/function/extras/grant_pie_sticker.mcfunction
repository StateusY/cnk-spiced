execute if entity @s[advancements={summit.sticker_book:spiced/huntsman_pie=true}] run title @s actionbar {text:""}
advancement grant @s only summit.sticker_book:spiced/huntsman_pie