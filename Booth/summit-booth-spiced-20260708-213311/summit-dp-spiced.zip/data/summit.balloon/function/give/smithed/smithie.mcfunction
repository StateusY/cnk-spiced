function summit.balloon:give/balloon {model:'smithed.smithie', name:'Smithie'}
