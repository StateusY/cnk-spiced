function summit.balloon:give/balloon {model:'smithed.smithed_basic', name:'Smithed Basic'}
