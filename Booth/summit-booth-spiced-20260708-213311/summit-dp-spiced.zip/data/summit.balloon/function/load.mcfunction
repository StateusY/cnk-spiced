scoreboard objectives add summit.balloon_cooldown.smithed.smithed_basic dummy
scoreboard objectives add summit.balloon_cooldown.smithed.smithie dummy
