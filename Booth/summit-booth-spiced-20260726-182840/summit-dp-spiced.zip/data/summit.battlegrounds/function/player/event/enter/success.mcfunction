advancement grant @s from summit:booth_exit_root
function #summit.booth:exit
tag @s add summit.battlegrounds.player
title @s actionbar ["", {text: "[Baobab Battlegrounds] ", color: "gold"}, {text: "You have entered the battlegrounds.", color: "green"}]
execute store result score @s summit.battlegrounds.schedule run schedule function summit.battlegrounds:player/event/enter/schedule 1
