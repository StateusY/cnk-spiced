tag @s remove summit.silence_birds
