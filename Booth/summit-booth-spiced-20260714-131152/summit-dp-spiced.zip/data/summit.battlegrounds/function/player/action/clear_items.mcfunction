clear @s *
