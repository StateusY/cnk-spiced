$function $(struct_function)
function summit.battlegrounds:utility/clear_kits with storage summit.battlegrounds:database session
function #summit.battlegrounds:api/booth_active
