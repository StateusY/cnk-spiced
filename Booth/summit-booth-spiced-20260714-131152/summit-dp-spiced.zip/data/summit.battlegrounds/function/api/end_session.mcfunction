data modify storage summit.battlegrounds:temp booth_id set from storage summit.battlegrounds:database session.booth_id
$execute store result score #no_match summit.battlegrounds run data modify storage summit.battlegrounds:temp booth_id set value $(booth_id)
execute if score #no_match summit.battlegrounds matches 1 run return -1
execute if score #no_match summit.battlegrounds matches 0 run function summit.battlegrounds:battleground/session/end
execute if score #no_match summit.battlegrounds matches 0 run return 1
