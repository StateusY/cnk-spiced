# get data
item replace block -30000000 0 0 container.0 from entity @s player.crafting.0

# set slot
data modify storage summit:temp balloon.slot set value "player.crafting.0"

# do checks and process
function summit.balloon:inventory/process