# get data
item replace block -30000000 0 0 container.0 from entity @s inventory.8

# set slot
data modify storage summit:temp balloon.slot set value "inventory.8"

# do checks and process
function summit.balloon:inventory/process