advancement revoke @s only summit.balloon:cursor

# get data
item replace block -30000000 0 0 container.0 from entity @s player.cursor
data modify storage summit:temp balloon.item set from block -30000000 0 0 Items[{Slot:0b}]

# get amount of contents
execute store result score $count summit.temp run data get storage summit:temp balloon.item.components."minecraft:bundle_contents"

# compare previous bundle contents amount to current bundle contents amount, if match then do nothing
execute store result score $old_count summit.temp run data get storage summit:temp balloon.item.components."minecraft:custom_data".summit.balloon.count
execute if score $old_count summit.temp = $count summit.temp run return fail

# get last item
data modify storage summit:temp balloon.last_item set from storage summit:temp balloon.item.components."minecraft:bundle_contents"[0]

# if last added item is not a balloon, remove
execute unless data storage summit:temp balloon.last_item{components:{"minecraft:custom_data":{"summit":{"balloon":{}}}}} run return run function summit.balloon:cursor/remove/main

# if bundle and only one item, unbundle
execute if score $count summit.temp matches 1 if data storage summit:temp balloon.item.components."minecraft:custom_data".summit.balloon.bundle run return run function summit.balloon:cursor/unbundle

# if not bundle and only one item, convert to balloon bundle
execute if score $count summit.temp matches 1 unless data storage summit:temp balloon.item.components."minecraft:custom_data".summit.balloon.bundle run function summit.balloon:cursor/bundle

# if last item is a balloon bundle, flatten
execute if data storage summit:temp balloon.last_item.components."minecraft:bundle_contents" run function summit.balloon:cursor/flatten

# update data based on bundle contents
function summit.balloon:update

# modify item using updated data
function summit.balloon:cursor/modify with storage summit:temp balloon.item