data modify storage summit:temp balloon.item set from storage summit:temp balloon.item.components."minecraft:bundle_contents"[0]

# have to set the bundle contents to nothing otherwise it doesn't take
data modify storage summit:temp balloon.item.components."minecraft:bundle_contents" set value []

# modify item using updated data
function summit.balloon:cursor/modify with storage summit:temp balloon.item