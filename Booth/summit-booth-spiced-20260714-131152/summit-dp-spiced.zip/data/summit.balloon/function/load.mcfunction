scoreboard objectives add summit.balloon_cooldown.spiced.mortar_balloon dummy
