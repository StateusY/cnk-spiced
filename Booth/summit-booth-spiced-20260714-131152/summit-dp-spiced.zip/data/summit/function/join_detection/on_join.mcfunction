scoreboard players set @s summit.on_join 0
function #summit:api/reset_player
