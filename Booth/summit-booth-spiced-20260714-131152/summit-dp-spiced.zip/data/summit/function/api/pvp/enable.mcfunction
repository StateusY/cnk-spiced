attribute @s minecraft:attack_damage modifier remove summit:no_attack_damage
