# Generated with MC-Build

execute positioned 225 52 197 run advancement grant @p[tag=summit.in_booth.spiced,distance=..12,limit=4] only spiced:npcs/stateus
function spiced:stateus_npc/says {message:[{text:'Actually', color: '#3a552c'}, ' the', ' \'e\'', ' in', ' \'Stateus\'', ' is', ' silent,']}
schedule function spiced:stateus_npc/zzz/25 80t replace