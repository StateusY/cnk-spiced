# Generated with MC-Build

execute positioned 225 52 197 run advancement grant @p[tag=summit.in_booth.spiced,distance=..12,limit=4] only spiced:npcs/stateus
function spiced:stateus_npc/says {message:[{text:'I\'ve', color: '#3a552c'}, ' been', ' playing', ' the', ' guitar', ' for', ' ~2', ' years']}
schedule function spiced:stateus_npc/zzz/121 80t replace