
# get player kit
data remove storage summit.battlegrounds:api/response get_kit
$data modify storage summit.battlegrounds:api/response get_kit set from storage summit.battlegrounds:database kits[{player_id:$(id)}]
execute if data storage summit.battlegrounds:api/response get_kit run return 1
return -1
