
# notify player
tellraw @s ["", {text: "[Baobab Battlegrounds] ", color: "gold"}, {text: "You have selected ", color: "green"}, {nbt: "assign_kit.kit_name", storage: "summit.battlegrounds:macro", color: "green", interpret: true}, {text: "!", color: "green"}]

# update the players kit and reset expiration
$data remove storage summit.battlegrounds:database kits[{player_id:$(player_id)}]
data modify storage summit.battlegrounds:database kits append from storage summit.battlegrounds:macro assign_kit
scoreboard players set @s summit.battlegrounds.kit_expiration 180
