execute store result score $chance summit.temp run random value 1..100
execute store result score $bird_chance summit.temp run data get entity @s data.summit_bird.bird_chance
execute if score $bird_chance summit.temp < $chance summit.temp run return fail

scoreboard players add @s summit.bird_count 1

# store marker data
data modify storage summit:temp bird_spawner set from entity @s data.summit_bird

# bird home offset
execute store result storage summit:temp bird_spawner.radius int 1000 run data get storage summit:temp bird_spawner.spawn_radius
function summit.birds:spawner/home_offset with storage summit:temp bird_spawner

# find bird home
execute summon minecraft:marker run function summit.birds:spawner/find_home with storage summit:temp bird_spawner

# bird spawn offset
execute store result storage summit:temp bird_spawner.x_offset int 1 run random value -5..5
execute store result storage summit:temp bird_spawner.y_offset int 1 run random value -5..5

# store bird id
scoreboard players operation $bird_id summit.temp = @s summit.bird_id

# spawn a dang bird
function summit.birds:bird/spawn with storage summit:temp bird_spawner
