# @s = @e[type=item_display, tag=summit_flag, tag=summit_flag.wind_sync]
# at undefined
# run by summit:flag/wind_sync/random_shift

execute store result entity @s Rotation[0] float 1 run scoreboard players get #wind_direction summit.flag
