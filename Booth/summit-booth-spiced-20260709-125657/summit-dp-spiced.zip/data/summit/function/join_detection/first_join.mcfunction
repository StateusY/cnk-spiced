#> On Join Handling
# as/at @s = player who joined
# run from summit:tick

# REMOVED API TAG, WE WANT THIS RESERVERD FOR THE CUTSCENE