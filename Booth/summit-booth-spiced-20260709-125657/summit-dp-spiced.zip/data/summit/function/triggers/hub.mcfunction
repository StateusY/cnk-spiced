#> Hub Trigger
# as @s = player triggering hub
# run from summit:tick (or manually)

scoreboard players set @s spawn 0
function #summit:api/reset_player
execute in minecraft:overworld run tp @s 0 225 0
