# @s = player
# at undefined
# run by summit:api/item_handling/clear_all_modifiers

data modify storage summit:temp player_items set from entity @s
function summit:item_handling/modifies_attributes/store/cache with storage summit:temp player_items
data remove storage summit:temp player_items
