# @s = player
# at undefined
# run by summit:item_handling/modifies_attributes/restore/equipment/chest
# run by summit:item_handling/modifies_attributes/restore/equipment/feet
# run by summit:item_handling/modifies_attributes/restore/equipment/head
# run by summit:item_handling/modifies_attributes/restore/equipment/legs
# run by summit:item_handling/modifies_attributes/restore/equipment/offhand

$loot replace entity @s $(slot) loot {"pools": [{"rolls": 1, "entries": [{"type": "minecraft:item","name": "$(id)","functions": [{"function": "minecraft:set_count", "count": $(count)},{"function": "minecraft:set_components", "components": $(components)}]}]}]}
