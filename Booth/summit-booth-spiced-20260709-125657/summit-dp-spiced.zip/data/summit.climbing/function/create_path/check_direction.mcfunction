# init
$data modify storage summit.climbing:master init.tile_data.$(direction) set value {}

# check all valid spots
$execute unless data entity @s {Facing:1b} positioned $(coord_prefix)1$(coord_suffix) ^ as @n[type=minecraft:item_frame,predicate=summit.climbing:is_path,distance=..0.1] run function summit.climbing:create_path/item_frame_found {direction:"$(direction)",relation:"direct_0"}
$execute unless data entity @s {Facing:1b} positioned $(coord_prefix)2$(coord_suffix) ^ as @n[type=minecraft:item_frame,predicate=summit.climbing:is_path,distance=..0.1] run function summit.climbing:create_path/item_frame_found {direction:"$(direction)",relation:"direct_1"}
$execute unless data entity @s {Facing:1b} positioned $(coord_prefix)3$(coord_suffix) ^ as @n[type=minecraft:item_frame,predicate=summit.climbing:is_path,distance=..0.1] run function summit.climbing:create_path/item_frame_found {direction:"$(direction)",relation:"direct_2"}
$execute positioned $(coord_prefix)0.5$(coord_suffix) ^0.5 as @n[type=minecraft:item_frame,predicate=summit.climbing:is_path,distance=..0.1] run function summit.climbing:create_path/item_frame_found {direction:"$(direction)",relation:"in"}
$execute positioned $(coord_prefix)0.5$(coord_suffix) ^-0.5 as @n[type=minecraft:item_frame,predicate=summit.climbing:is_path,distance=..0.1] run function summit.climbing:create_path/item_frame_found {direction:"$(direction)",relation:"out"}

# remove if no important data
$execute unless data storage summit.climbing:master init.tile_data.$(direction).direct_0 unless data storage summit.climbing:master init.tile_data.$(direction).direct_1 unless data storage summit.climbing:master init.tile_data.$(direction).direct_2 unless data storage summit.climbing:master init.tile_data.$(direction).in unless data storage summit.climbing:master init.tile_data.$(direction).out run data remove storage summit.climbing:master init.tile_data.$(direction)




