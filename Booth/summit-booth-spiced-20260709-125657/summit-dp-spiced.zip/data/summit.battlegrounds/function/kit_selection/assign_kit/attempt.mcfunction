
# get booth data for players kit
data remove storage summit.battlegrounds:temp target_booth
$data modify storage summit.battlegrounds:temp target_booth set from storage summit.battlegrounds:database booths[{booth_id:$(booth_id)}]
execute unless data storage summit.battlegrounds:temp target_booth run return -2

# check if compatibility matches current and session is active
data modify storage summit.battlegrounds:temp compatibility set from storage summit.battlegrounds:database session.compatibility
execute store result score #no_match summit.battlegrounds run data modify storage summit.battlegrounds:temp compatibility set from storage summit.battlegrounds:temp target_booth.compatibility
execute unless data storage summit.battlegrounds:database session run scoreboard players set #no_match summit.battlegrounds 0

# route based on if compatibility matches
execute if score #no_match summit.battlegrounds matches 0 run function summit.battlegrounds:kit_selection/assign_kit/success with storage summit.battlegrounds:macro assign_kit
$execute if score #no_match summit.battlegrounds matches 1 run function summit.battlegrounds:kit_selection/assign_kit/fail {booth_id:"$(booth_id)"}

# return value
execute if score #no_match summit.battlegrounds matches 1 run return -1
execute if score #no_match summit.battlegrounds matches 0 run return 1
