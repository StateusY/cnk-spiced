
# copy booth data and start session
$data modify storage summit.battlegrounds:database session set from storage summit.battlegrounds:database booths[{booth_id:$(booth_id)}]
function summit.battlegrounds:battleground/session/activate
