
# notify player
title @s actionbar ["", {text: "[Baobab Battlegrounds] ", color: "gold"}, {text: "You have left the battlegrounds.", color: "red"}]

# function tag
function #summit.battlegrounds:api/player_leave

# remove tag and clear player
tag @s remove summit.battlegrounds.player
function summit.battlegrounds:player/action/clear_items
