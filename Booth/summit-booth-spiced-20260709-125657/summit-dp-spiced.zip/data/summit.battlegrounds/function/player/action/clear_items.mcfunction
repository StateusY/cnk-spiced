
clear @s *
