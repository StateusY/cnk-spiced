
# reset timers
function summit.battlegrounds:battleground/reset_timers

# function tag
function #summit.battlegrounds:api/booth_inactive

# move to next booth in queue
function summit.battlegrounds:booth_queue/advance_queue

# reset players and give new kit
execute as @a run function summit.battlegrounds:player/action/clear_items
function summit.battlegrounds:kit_selection/unassign_kit/all
execute as @a[tag=summit.battlegrounds.player] run function summit.battlegrounds:player/action/give_kit
