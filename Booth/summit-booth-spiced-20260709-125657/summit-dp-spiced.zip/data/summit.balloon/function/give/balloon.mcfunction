# called with parameters:
# model: the base model of the balloon
# name: the name of the balloon item

# generate and apply unique stamp
execute summon minecraft:marker run function summit.balloon:give/stamp

# store model
$data modify storage summit:temp balloon.model set value "$(model)"

# Store name
$data modify storage summit:temp balloon.name set value "$(name)"

function summit.balloon:give/macro with storage summit:temp balloon