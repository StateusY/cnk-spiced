# @s = summit.node interaction with interaction data
# at undefined
# run from summit.dev:entity/node/interact

$execute on target run dialog show @s {type:"minecraft:multi_action",title:"Node Information",body:[{type:"minecraft:plain_message",contents:{text:"\ua000",font:"summit_technical:dialog"}},{type:"minecraft:plain_message",contents:{text:"There was an error getting this node's information. Please edit the name or description, or delete the node if the issue persists.",color:"#ff0000"}}, ],inputs:[],after_action:"close",columns:3,actions:[{label:"Edit Name",width:100,tooltip:"Edit the name of this node.",action:{type:"minecraft:run_command",command:"function summit.dev:entity/node/dialog/edit_node_pre {owner:\"$(owner)\",type:\"name\",id:\"$(id)\",text:\"Error fetching Node Name\",color:\"-1\"}"}},{label:"Edit Description",width:100,tooltip:"Edit the description of this node.",action:{type:"minecraft:run_command",command:"function summit.dev:entity/node/dialog/edit_node_pre {owner:\"$(owner)\",type:\"description\",id:\"$(id)\",text:\"Error fetching Node Description\",color:\"-1\"}"}},{label:"Delete Node",width:100,tooltip:"Delete this node.",action:{type:"minecraft:run_command",command:"function summit.dev:entity/node/dialog/delete_try {name:$(owner),id:$(id)}"}}]}









