# @s = node creator via dialog
# at @s
# run from summit.dev:entity/node/dialog/delete_try

$execute as @n[type=item_display,scores={summit.dev.nodeID=$(id)}] at @s run function summit.dev:entity/node/delete {id:$(id)}
tag @s remove deletingNode
