# update all info
# @s = interaction riding node item_display
# location doesn't matter
# run from summit.dev:entity/node/init
# run from summit.dev:entity/node/macro/edit_node_claim
# run from summit.dev:entity/node/macro/edit_node_complete
# run from summit.dev:entity/node/macro/edit_node_coords
# run from summit.dev:entity/node/macro/edit_node_incomplete
# run from summit.dev:entity/node/macro/edit_node_unclaim
# run from summit.dev:entity/node/macro/edit_node

$data modify storage summit:root dev.nodeList[{id:$(id)}] merge from entity @s data
