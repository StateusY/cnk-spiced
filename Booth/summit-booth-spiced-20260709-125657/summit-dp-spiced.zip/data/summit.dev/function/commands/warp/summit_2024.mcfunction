# run from dialog: summit:development_tools

execute in summit:2024 run tp @s 0 73 0
