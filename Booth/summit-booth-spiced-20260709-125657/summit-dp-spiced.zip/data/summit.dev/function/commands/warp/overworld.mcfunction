# run from dialog: summit:development_tools

execute in minecraft:overworld run tp @s 0 225 0
