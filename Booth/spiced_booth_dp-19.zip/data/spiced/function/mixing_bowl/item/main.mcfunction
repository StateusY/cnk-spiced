#------------------------------------------------------------------------------------
# HEY! This file is code from Crop & Kettle by Creature Comforts!
# We have been given permission to utilize it for use at smithed summit by MaybeJake.
# We do NOT claim any legal right or creative license to this file.
#------------------------------------------------------------------------------------

execute if score @s spiced.item_count matches 4.. run return run function spiced:mixing_bowl/mix/main
swing @p[tag=spiced.interact_mixing_bowl,distance=..20,limit=1] mainhand

scoreboard players operation $global spiced.item_count = @s spiced.item_count
execute summon minecraft:item_display at @s run function spiced:mixing_bowl/item/place
scoreboard players operation @s spiced.item_count = $global spiced.item_count