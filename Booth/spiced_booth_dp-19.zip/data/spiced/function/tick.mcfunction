execute positioned 210 63 188 run function spiced:positioned_tick

# npcs
function spiced:stateus_npc/tick
function spiced:pan_womsacz_npc/tick
function spiced:c4t_npc/tick
function spiced:mantis_npc/tick
function spiced:blue_npc/tick
function spiced:vault_emma_npc/tick