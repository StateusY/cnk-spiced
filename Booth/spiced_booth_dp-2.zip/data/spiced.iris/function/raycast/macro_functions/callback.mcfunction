#> spiced.iris:raycast/macro_functions/callback
#
# Calls the provided function
#
# @within spiced.iris:raycast/on_hit
# @input
#   function: a function name or function tag name

$function $(function)
