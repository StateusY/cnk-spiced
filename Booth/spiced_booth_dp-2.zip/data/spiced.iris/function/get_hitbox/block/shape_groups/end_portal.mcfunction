data modify storage spiced.iris:data Shape set value [{min: [0.0, 0.375, 0.0], max: [1.0, 0.75, 1.0]}]
