data modify storage spiced.iris:data Shape set value [{min: [0.0, 0.0, 0.0], max: [0.5, 0.75, 0.5]}]
