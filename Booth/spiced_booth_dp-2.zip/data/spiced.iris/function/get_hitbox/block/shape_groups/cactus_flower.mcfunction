data modify storage spiced.iris:data Shape set value [{min: [0.0625, 0.0, 0.0625], max: [0.9375, 0.75, 0.9375]}]
