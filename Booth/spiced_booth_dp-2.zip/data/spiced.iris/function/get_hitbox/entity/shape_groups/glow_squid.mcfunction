scoreboard players set $entity_width spiced.iris 800000
scoreboard players set $entity_height spiced.iris 800000
