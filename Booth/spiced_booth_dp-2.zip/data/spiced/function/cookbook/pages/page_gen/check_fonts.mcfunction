#------------------------------------------------------------------------------------
# HEY! This file is code from Crop & Kettle by Creature Comforts!
# We have been given permission to utilize it for use at smithed summit by MaybeJake.
# We do NOT claim any legal right or creative license to this file.
#------------------------------------------------------------------------------------

execute if data storage spiced:temp register.ingredients[0] run function spiced:cookbook/pages/page_gen/check_font with storage spiced:temp register.ingredients[0]
execute if data storage spiced:temp register.ingredients[0] run data modify storage spiced:temp register.ingredients[0].font set from storage spiced:temp register.temp_font

execute if data storage spiced:temp register.ingredients[1] run function spiced:cookbook/pages/page_gen/check_font with storage spiced:temp register.ingredients[1]
execute if data storage spiced:temp register.ingredients[1] run data modify storage spiced:temp register.ingredients[1].font set from storage spiced:temp register.temp_font

execute if data storage spiced:temp register.ingredients[2] run function spiced:cookbook/pages/page_gen/check_font with storage spiced:temp register.ingredients[2]
execute if data storage spiced:temp register.ingredients[2] run data modify storage spiced:temp register.ingredients[2].font set from storage spiced:temp register.temp_font

execute if data storage spiced:temp register.ingredients[3] run function spiced:cookbook/pages/page_gen/check_font with storage spiced:temp register.ingredients[3]
execute if data storage spiced:temp register.ingredients[3] run data modify storage spiced:temp register.ingredients[3].font set from storage spiced:temp register.temp_font

execute if data storage spiced:temp register.ingredients[4] run function spiced:cookbook/pages/page_gen/check_font with storage spiced:temp register.ingredients[4]
execute if data storage spiced:temp register.ingredients[4] run data modify storage spiced:temp register.ingredients[4].font set from storage spiced:temp register.temp_font

data modify storage spiced:temp register.font_check.key set from storage spiced:temp register.page_name
data modify storage spiced:temp register.font_check.font set from storage spiced:temp register.recipe_icon_font
function spiced:cookbook/pages/page_gen/check_font with storage spiced:temp register.font_check
data modify storage spiced:temp register.recipe_icon_font set from storage spiced:temp register.temp_font