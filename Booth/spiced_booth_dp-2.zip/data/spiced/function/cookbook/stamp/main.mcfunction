#------------------------------------------------------------------------------------
# HEY! This file is code from Crop & Kettle by Creature Comforts!
# We have been given permission to utilize it for use at smithed summit by MaybeJake.
# We do NOT claim any legal right or creative license to this file.
#------------------------------------------------------------------------------------

execute if data storage spiced:temp cookbook.current_page.stamp.text run return run function spiced:cookbook/stamp/build with storage spiced:temp cookbook.current_page.stamp
execute if data storage spiced:temp cookbook.current_page.stamp run data modify storage spiced:temp cookbook.data.stamp set from storage spiced:temp cookbook.current_page.stamp.icon