scoreboard players set @s summit.battlegrounds.kit_expiration 180
$function $(kit_function)
