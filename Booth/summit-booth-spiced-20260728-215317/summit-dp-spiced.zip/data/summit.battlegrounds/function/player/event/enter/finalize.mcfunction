function summit.inventory_management:save
function summit.battlegrounds:player/action/give_kit
function #summit.battlegrounds:api/player_enter
