title @s actionbar ["", {text: "[Baobab Battlegrounds] ", color: "gold"}, {text: "You have left the battlegrounds.", color: "red"}]
function #summit.battlegrounds:api/player_leave
function summit:api/reset_spawn_point
tag @s remove summit.battlegrounds.player
function summit.inventory_management:load
