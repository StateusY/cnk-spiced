execute store result score #gametime summit.battlegrounds run time query gametime
execute as @a[tag=summit.battlegrounds.player] at @s if score @s summit.battlegrounds.schedule = #gametime summit.battlegrounds run function summit.battlegrounds:player/event/enter/finalize
