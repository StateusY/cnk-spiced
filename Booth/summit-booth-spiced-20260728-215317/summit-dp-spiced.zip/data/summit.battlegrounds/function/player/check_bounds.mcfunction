execute store success score #entrance_level summit.battlegrounds if predicate summit.battlegrounds:entrance_level
execute store success score #enter_depth summit.battlegrounds if predicate summit.battlegrounds:enter_depth
execute store success score #absolute_bounds summit.battlegrounds if predicate summit.battlegrounds:absolute_bounds
execute store success score #hole_width summit.battlegrounds if block ~ 55 ~ green_concrete
execute if entity @s[tag=summit.battlegrounds.player] if score #absolute_bounds summit.battlegrounds matches 0 run function summit.battlegrounds:player/event/leave
execute if entity @s[tag=summit.battlegrounds.player, tag=!summit.battlegrounds.return] if score #hole_width summit.battlegrounds matches 0 if score #enter_depth summit.battlegrounds matches 0 run function summit.battlegrounds:player/event/leave_above
execute if entity @s[tag=summit.battlegrounds.player, tag=!summit.battlegrounds.return] if score #hole_width summit.battlegrounds matches 0 if score #entrance_level summit.battlegrounds matches 1 run function summit.battlegrounds:player/event/leave
execute if entity @s[tag=!summit.battlegrounds.player, gamemode=!creative, gamemode=!spectator] if score #hole_width summit.battlegrounds matches 1 if score #enter_depth summit.battlegrounds matches 1 run function summit.battlegrounds:player/event/enter
execute if entity @s[tag=summit.battlegrounds.return] if score #hole_width summit.battlegrounds matches 1 run function summit.battlegrounds:player/event/return
