function summit.battlegrounds:battleground/reset_timers
function #summit.battlegrounds:api/booth_inactive
execute as @a[tag=summit.battlegrounds.player] run function #summit.battlegrounds:api/player_leave
function summit.battlegrounds:api/set_structure {booth_id: "official_summit", structure: "summit.battlegrounds:default"}
function summit.battlegrounds:booth_queue/advance_queue
execute as @a[tag=summit.battlegrounds.player] run function summit.battlegrounds:player/action/clear_items
function summit.battlegrounds:kit_selection/unassign_kit/all
execute as @a[tag=summit.battlegrounds.player] run function summit.battlegrounds:player/action/give_kit
execute as @a[tag=summit.battlegrounds.player] run function #summit.battlegrounds:api/player_enter
