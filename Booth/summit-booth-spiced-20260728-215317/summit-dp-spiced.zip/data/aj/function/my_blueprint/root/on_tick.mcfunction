execute if entity @s[tag=aj.my_blueprint.animation.beat_1.playing] run function aj:my_blueprint/animations/beat_1/zzz/on_tick
execute if entity @s[tag=aj.my_blueprint.animation.beat_2.playing] run function aj:my_blueprint/animations/beat_2/zzz/on_tick
execute if entity @s[tag=aj.my_blueprint.animation.beat_3.playing] run function aj:my_blueprint/animations/beat_3/zzz/on_tick
execute if entity @s[tag=aj.my_blueprint.animation.beat_4.playing] run function aj:my_blueprint/animations/beat_4/zzz/on_tick
execute if entity @s[tag=aj.my_blueprint.animation.beat_5.playing] run function aj:my_blueprint/animations/beat_5/zzz/on_tick
execute if entity @s[tag=aj.my_blueprint.animation.beat_6.playing] run function aj:my_blueprint/animations/beat_6/zzz/on_tick
execute if entity @s[tag=aj.my_blueprint.animation.loop_test.playing] run function aj:my_blueprint/animations/loop_test/zzz/on_tick
execute on passengers run rotate @s ~ ~
