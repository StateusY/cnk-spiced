scoreboard objectives remove aj.beat_1.frame
scoreboard objectives remove aj.beat_2.frame
scoreboard objectives remove aj.beat_3.frame
scoreboard objectives remove aj.beat_4.frame
scoreboard objectives remove aj.beat_5.frame
scoreboard objectives remove aj.beat_6.frame
scoreboard objectives remove aj.loop_test.frame
tellraw @a [[{color: "gray", text: "\n "}, {color: "#00aced", text: "\u1d00\u0274\u026a\u1d0d\u1d00\u1d1b\u1d07\u1d05 \u1d0a\u1d00\u1d20\u1d00"}, {color: "dark_gray", italic: true, text: "\n (aj:my_blueprint)"}, "\n \u2192 "], [{text: "Successfully uninstalled ", color: "green"}, {text: "aj:my_blueprint", color: "yellow"}, {text: "!"}, {text: "\n If you have exported multiple times, you may have to remove objectives from previous exports manually, as Animated Java only knows about the objectives from the most recent export.", color: "gray", italic: true}], "\n"]
