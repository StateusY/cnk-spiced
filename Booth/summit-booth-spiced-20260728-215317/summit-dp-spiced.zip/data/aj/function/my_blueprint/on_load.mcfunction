data modify storage aj:my_blueprint rig_hash set value "c98dbb8121143afa90ebd0d04212405de5bd3283089c1e7c3338689ab290eb5d"
scoreboard objectives add aj.beat_1.frame dummy
scoreboard objectives add aj.beat_2.frame dummy
scoreboard objectives add aj.beat_3.frame dummy
scoreboard objectives add aj.beat_4.frame dummy
scoreboard objectives add aj.beat_5.frame dummy
scoreboard objectives add aj.beat_6.frame dummy
scoreboard objectives add aj.loop_test.frame dummy
