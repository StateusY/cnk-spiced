$function aj:my_blueprint/animations/loop_test/zzz/frames/$(frame) with storage animated_java:temp entry.data.uuids_by_name
execute on passengers run data modify entity @s start_interpolation set value -1
return 1
