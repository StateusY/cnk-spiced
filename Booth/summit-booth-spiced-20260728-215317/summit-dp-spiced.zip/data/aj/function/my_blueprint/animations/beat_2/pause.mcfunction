tag @s remove aj.my_blueprint.animation.beat_2.playing
