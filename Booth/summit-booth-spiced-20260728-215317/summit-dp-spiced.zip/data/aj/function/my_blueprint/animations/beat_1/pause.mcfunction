tag @s remove aj.my_blueprint.animation.beat_1.playing
