execute store result storage animated_java:temp args.id int 1 run scoreboard players get @s aj.id
function animated_java:global/data_manager/read with storage animated_java:temp args
function aj:my_blueprint/animations/pause_all
tag @s add aj.my_blueprint.animation.beat_6.playing
scoreboard players set @s aj.beat_6.frame 0
tag @s add aj.transforms_only
execute at @s run function aj:my_blueprint/animations/beat_6/zzz/set_frame {frame: 0}
tag @s remove aj.transforms_only
