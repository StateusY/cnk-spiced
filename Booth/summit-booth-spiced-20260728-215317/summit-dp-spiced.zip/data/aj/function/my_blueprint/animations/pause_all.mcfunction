tag @s remove aj.my_blueprint.animation.beat_1.playing
tag @s remove aj.my_blueprint.animation.beat_2.playing
tag @s remove aj.my_blueprint.animation.beat_3.playing
tag @s remove aj.my_blueprint.animation.beat_4.playing
tag @s remove aj.my_blueprint.animation.beat_5.playing
tag @s remove aj.my_blueprint.animation.beat_6.playing
tag @s remove aj.my_blueprint.animation.loop_test.playing
