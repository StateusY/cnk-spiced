scoreboard players remove @s aj.tween_duration 1
execute if score @s aj.tween_duration matches 1.. run return 1
execute if score @s aj.tween_duration matches 0 on passengers run data modify entity @s interpolation_duration set value 1
data remove storage animated_java:temp args
execute store result storage animated_java:temp args.frame int 1 run scoreboard players get @s aj.beat_1.frame
function aj:my_blueprint/animations/beat_1/zzz/apply_frame with storage animated_java:temp args
execute if score @s aj.beat_1.frame matches 8 run return run function aj:my_blueprint/animations/beat_1/zzz/loop_mode_stop
scoreboard players add @s aj.beat_1.frame 1
