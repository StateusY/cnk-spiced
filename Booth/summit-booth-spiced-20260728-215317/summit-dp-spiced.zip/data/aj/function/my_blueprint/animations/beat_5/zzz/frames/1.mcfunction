$data merge entity $(cable_1) {transformation: [-1.0062f,-0.0006f,0f,0.6875f,-0.0006f,1f,0f,0.0641f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_2) {transformation: [-1.0562f,-0.013f,0f,0.7813f,-0.0138f,0.9999f,0f,0.6563f,0f,0f,-1f,-0.4375f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_1) {transformation: [-1.0372f,0.0019f,0.4296f,-0.5562f,0f,1.1226f,-0.0049f,0.4834f,-0.4296f,-0.0045f,-1.0371f,0.2665f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_2) {transformation: [-1.0372f,0.0019f,0.4296f,-0.4111f,0f,1.1226f,-0.0049f,0.9522f,-0.4296f,-0.0045f,-1.0371f,0.3244f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_4) {transformation: [-0.9239f,0.0031f,0.3827f,-0.5435f,0f,1.9f,-0.0043f,0.2013f,-0.3827f,-0.0076f,-0.9239f,-0.3358f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_box) {transformation: [-0.9239f,0.0017f,0.3827f,-0.4946f,0f,1f,-0.0043f,0.1389f,-0.3827f,-0.004f,-0.9239f,0.0907f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
