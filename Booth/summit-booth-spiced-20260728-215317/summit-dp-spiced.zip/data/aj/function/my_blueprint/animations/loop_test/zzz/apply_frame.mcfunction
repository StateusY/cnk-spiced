$function aj:my_blueprint/animations/loop_test/zzz/frames/$(frame) with storage animated_java:temp entry.data.uuids_by_name
return 1
