tag @s remove aj.my_blueprint.animation.beat_4.playing
