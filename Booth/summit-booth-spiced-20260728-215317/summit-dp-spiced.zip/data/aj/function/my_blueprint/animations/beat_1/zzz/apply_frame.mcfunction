$function aj:my_blueprint/animations/beat_1/zzz/frames/$(frame) with storage animated_java:temp entry.data.uuids_by_name
return 1
