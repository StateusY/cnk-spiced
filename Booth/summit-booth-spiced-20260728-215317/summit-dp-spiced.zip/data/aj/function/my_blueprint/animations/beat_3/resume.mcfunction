tag @s add aj.my_blueprint.animation.beat_3.playing
