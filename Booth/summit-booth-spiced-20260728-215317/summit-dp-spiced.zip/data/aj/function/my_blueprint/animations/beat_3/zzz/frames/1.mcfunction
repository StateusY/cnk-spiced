$data merge entity $(cable_1) {transformation: [-1.0059f,0.0257f,0f,0.6875f,0.0259f,0.9997f,0f,0.0641f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_2) {transformation: [-1.0312f,0.0124f,0f,0.7813f,0.0128f,0.9999f,0f,0.6563f,0f,0f,-1f,-0.4375f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_1) {transformation: [-1.037f,-0.0067f,0.43f,-0.5589f,-0.0045f,1.1226f,0.0067f,0.4816f,-0.43f,0.0045f,-1.037f,0.2692f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_2) {transformation: [-1.037f,-0.0067f,0.43f,-0.4173f,-0.0045f,1.1226f,0.0067f,0.9509f,-0.43f,0.0045f,-1.037f,0.331f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_4) {transformation: [-0.9237f,-0.0113f,0.383f,-0.5438f,-0.004f,1.9f,0.006f,0.2044f,-0.383f,0.0076f,-0.9237f,-0.3353f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_box) {transformation: [-0.9237f,-0.006f,0.383f,-0.4946f,-0.004f,1f,0.006f,0.1389f,-0.383f,0.004f,-0.9237f,0.0907f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
