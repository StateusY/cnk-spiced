tag @s add aj.my_blueprint.animation.beat_1.playing
