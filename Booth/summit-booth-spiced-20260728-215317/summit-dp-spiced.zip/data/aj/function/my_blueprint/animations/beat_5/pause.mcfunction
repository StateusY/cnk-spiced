tag @s remove aj.my_blueprint.animation.beat_5.playing
