tag @s add aj.my_blueprint.animation.beat_4.playing
