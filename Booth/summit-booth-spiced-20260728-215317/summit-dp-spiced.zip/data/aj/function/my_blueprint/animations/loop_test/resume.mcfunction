tag @s add aj.my_blueprint.animation.loop_test.playing
