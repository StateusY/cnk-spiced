$data merge entity $(cable_1) {transformation: [-1.0052f,0.0462f,0f,0.6875f,0.0465f,0.9989f,0f,0.0641f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_2) {transformation: [-1.031f,0.0203f,0f,0.7813f,0.0209f,0.9998f,0f,0.6563f,0f,0f,-1f,-0.4375f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_1) {transformation: [-1.037f,0.0067f,0.43f,-0.5548f,0.0045f,1.1226f,-0.0067f,0.4837f,-0.43f,-0.0045f,-1.037f,0.2665f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_2) {transformation: [-1.037f,0.0067f,0.43f,-0.4076f,0.0045f,1.1226f,-0.0067f,0.9518f,-0.43f,-0.0045f,-1.037f,0.3245f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_4) {transformation: [-0.9237f,0.0113f,0.383f,-0.5431f,0.004f,1.9f,-0.006f,0.2015f,-0.383f,-0.0076f,-0.9237f,-0.3358f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_box) {transformation: [-0.9237f,0.006f,0.383f,-0.4946f,0.004f,1f,-0.006f,0.1389f,-0.383f,-0.004f,-0.9237f,0.0907f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
