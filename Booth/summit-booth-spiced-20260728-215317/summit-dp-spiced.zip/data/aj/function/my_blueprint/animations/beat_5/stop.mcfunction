execute store result storage animated_java:temp args.id int 1 run scoreboard players get @s aj.id
function animated_java:global/data_manager/read with storage animated_java:temp args
function aj:my_blueprint/animations/pause_all
scoreboard players set @s aj.beat_5.frame 0
tag @s add aj.transforms_only
execute at @s run function aj:my_blueprint/animations/beat_5/zzz/set_frame {frame: 0}
tag @s remove aj.transforms_only
