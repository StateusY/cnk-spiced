execute store result storage animated_java:temp args.id int 1 run scoreboard players get @s aj.id
function animated_java:global/data_manager/read with storage animated_java:temp args
execute if score @s aj.loop_test.frame matches 54.. run scoreboard players set @s aj.loop_test.frame 1
data remove storage animated_java:temp args
execute store result storage animated_java:temp args.frame int 1 run scoreboard players get @s aj.loop_test.frame
execute at @s run function aj:my_blueprint/animations/loop_test/zzz/apply_frame with storage animated_java:temp args
scoreboard players add @s aj.loop_test.frame 1
