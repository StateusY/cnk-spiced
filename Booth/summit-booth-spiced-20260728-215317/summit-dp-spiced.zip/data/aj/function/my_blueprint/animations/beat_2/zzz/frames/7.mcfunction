$data merge entity $(text_display) {transformation: [0.199f,0.0198f,0f,0.5587f,-0.0198f,0.199f,0f,0.6123f,0f,0f,0.2f,0.5641f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_1) {transformation: [-1.0022f,0.0901f,0f,0.6951f,0.0906f,0.9959f,0f,0.0885f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_2) {transformation: [-1.0299f,0.0513f,0f,0.8469f,0.0529f,0.9987f,0f,0.6685f,0f,0f,-1f,-0.4375f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(stereo) {transformation: [-0.9951f,0.0988f,0f,0.9375f,0.0988f,0.9951f,0f,0f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_1) {transformation: [-0.9844f,0.0053f,0.4081f,-0.5551f,0.0036f,1.0656f,-0.0053f,0.3596f,-0.4081f,-0.0036f,-0.9844f,0.2667f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_2) {transformation: [-0.9844f,0.0053f,0.4081f,-0.4084f,0.0036f,1.0656f,-0.0053f,0.8279f,-0.4081f,-0.0036f,-0.9844f,0.325f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_4) {transformation: [-0.9238f,0.0044f,0.383f,-0.5431f,0.0034f,0.8746f,-0.005f,0.0779f,-0.383f,-0.0029f,-0.9238f,-0.3357f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_box) {transformation: [-0.9238f,0.005f,0.383f,-0.4946f,0.0034f,1f,-0.005f,0.015f,-0.383f,-0.0034f,-0.9238f,0.0907f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
