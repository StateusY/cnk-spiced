$data merge entity $(text_display) {transformation: [0.2f,-0.0037f,0f,0.4894f,0.0037f,0.2f,0f,0.5636f,0f,0f,0.2f,0.5641f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_1) {transformation: [-1.0108f,0.0582f,0f,0.6863f,0.0589f,0.9983f,0f,0.0594f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_2) {transformation: [-1.0622f,0.0242f,0f,0.769f,0.0257f,0.9997f,0f,0.6532f,0f,0f,-1f,-0.4375f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(stereo) {transformation: [-0.9998f,-0.0186f,0f,0.9375f,-0.0186f,0.9998f,0f,0f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_1) {transformation: [-1.0677f,0.1329f,0.4419f,-0.517f,0.0884f,1.1521f,-0.1329f,0.5834f,-0.4529f,-0.0884f,-1.0677f,0.2407f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_2) {transformation: [-1.0677f,0.1329f,0.4419f,-0.32f,0.0884f,1.1521f,-0.1329f,1.0358f,-0.4529f,-0.0884f,-1.0677f,0.2659f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_4) {transformation: [-0.918f,0.32f,0.3799f,-0.5361f,0.076f,2.7735f,-0.1143f,0.2587f,-0.3893f,-0.2128f,-0.918f,-0.3395f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_box) {transformation: [-0.918f,0.1143f,0.3799f,-0.4946f,0.076f,0.9905f,-0.1143f,0.2222f,-0.3893f,-0.076f,-0.918f,0.0907f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
