$function aj:my_blueprint/animations/beat_3/zzz/frames/$(frame) with storage animated_java:temp entry.data.uuids_by_name
return 1
