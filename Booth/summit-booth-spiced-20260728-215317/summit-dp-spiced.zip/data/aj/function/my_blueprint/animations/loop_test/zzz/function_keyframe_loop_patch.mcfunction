function aj:my_blueprint/animations/loop_test/zzz/frames/last_frame_effects with storage animated_java:temp entry.data.uuids_by_name
scoreboard players add @s aj.loop_test.frame 1
