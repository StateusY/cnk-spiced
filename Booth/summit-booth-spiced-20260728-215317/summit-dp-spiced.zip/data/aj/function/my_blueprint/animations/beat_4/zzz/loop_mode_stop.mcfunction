scoreboard players set @s aj.beat_4.frame 0
tag @s add aj.transforms_only
execute at @s run function aj:my_blueprint/animations/beat_4/zzz/zzz/set_frame {frame: 0}
tag @s remove aj.transforms_only
tag @s remove aj.my_blueprint.animation.beat_4.playing
