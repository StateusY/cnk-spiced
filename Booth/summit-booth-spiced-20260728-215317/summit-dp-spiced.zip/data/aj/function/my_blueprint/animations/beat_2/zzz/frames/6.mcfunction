$data merge entity $(text_display) {transformation: [0.1974f,0.0319f,0f,0.5969f,-0.0319f,0.1974f,0f,0.6344f,0f,0f,0.2f,0.5641f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_1) {transformation: [-1.0063f,0.1109f,0f,0.7009f,0.1123f,0.9938f,0f,0.1032f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_2) {transformation: [-1.0612f,0.049f,0f,0.888f,0.0521f,0.9988f,0f,0.6728f,0f,0f,-1f,-0.4375f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(stereo) {transformation: [-0.9872f,0.1597f,0f,0.9375f,0.1597f,0.9872f,0f,0f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_1) {transformation: [-1.053f,0.0274f,0.4376f,-0.5487f,0.0183f,1.1401f,-0.0274f,0.4048f,-0.4381f,-0.0183f,-1.053f,0.2623f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_2) {transformation: [-1.053f,0.0274f,0.4376f,-0.3932f,0.0183f,1.1401f,-0.0274f,0.8709f,-0.4381f,-0.0183f,-1.053f,0.3147f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_4) {transformation: [-0.9232f,0.0176f,0.3837f,-0.5415f,0.0161f,0.7314f,-0.0241f,0.1152f,-0.3841f,-0.0117f,-0.9232f,-0.3366f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_box) {transformation: [-0.9232f,0.0241f,0.3837f,-0.4946f,0.0161f,0.9996f,-0.0241f,0.0569f,-0.3841f,-0.0161f,-0.9232f,0.0907f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
