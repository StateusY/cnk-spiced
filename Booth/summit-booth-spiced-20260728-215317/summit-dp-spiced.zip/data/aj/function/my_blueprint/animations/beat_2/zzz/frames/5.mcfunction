$data merge entity $(text_display) {transformation: [0.1959f,0.0405f,0f,0.6247f,-0.0405f,0.1959f,0f,0.6486f,0f,0f,0.2f,0.5641f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_1) {transformation: [-1.0173f,0.0525f,0f,0.7056f,0.0535f,0.9986f,0f,0.1133f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_2) {transformation: [-1.0937f,0.0038f,0f,0.9172f,0.0041f,1f,0f,0.6743f,0f,0f,-1f,-0.4375f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(stereo) {transformation: [-0.9793f,0.2023f,0f,0.9375f,0.2023f,0.9793f,0f,0f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_1) {transformation: [-0.992f,0.1039f,0.4118f,-0.5235f,0.0691f,1.0719f,-0.1039f,0.3813f,-0.419f,-0.0691f,-0.992f,0.2451f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_2) {transformation: [-0.992f,0.1039f,0.4118f,-0.3348f,0.0691f,1.0719f,-0.1039f,0.8369f,-0.419f,-0.0691f,-0.992f,0.2757f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_4) {transformation: [-0.9193f,0.0887f,0.3816f,-0.5369f,0.064f,0.9154f,-0.0962f,0.0634f,-0.3883f,-0.059f,-0.9193f,-0.3391f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_box) {transformation: [-0.9193f,0.0962f,0.3816f,-0.4946f,0.064f,0.9933f,-0.0962f,0.0225f,-0.3883f,-0.064f,-0.9193f,0.0907f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
