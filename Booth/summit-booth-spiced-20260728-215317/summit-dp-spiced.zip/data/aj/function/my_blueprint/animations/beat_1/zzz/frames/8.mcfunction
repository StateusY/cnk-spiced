$data merge entity $(text_display) {transformation: [0.2f,0f,0f,0.5f,0f,0.2f,0f,0.5719f,0f,0f,0.2f,0.5641f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_1) {transformation: [-1f,0f,0f,0.6875f,0f,1f,0f,0.0641f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_2) {transformation: [-1f,0f,0f,0.7813f,0f,1f,0f,0.6563f,0f,0f,-1f,-0.4375f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(stereo) {transformation: [-1f,0f,0f,0.9375f,0f,1f,0f,0f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_1) {transformation: [-0.9239f,0f,0.3827f,-0.5568f,0f,1f,0f,0.3438f,-0.3827f,0f,-0.9239f,0.2679f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_2) {transformation: [-0.9239f,0f,0.3827f,-0.4124f,0f,1f,0f,0.8125f,-0.3827f,0f,-0.9239f,0.3277f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_4) {transformation: [-0.9239f,0f,0.3827f,-0.5436f,0f,1f,0f,0.0641f,-0.3827f,0f,-0.9239f,-0.3355f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_box) {transformation: [-0.9239f,0f,0.3827f,-0.4946f,0f,1f,0f,0f,-0.3827f,0f,-0.9239f,0.0907f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
