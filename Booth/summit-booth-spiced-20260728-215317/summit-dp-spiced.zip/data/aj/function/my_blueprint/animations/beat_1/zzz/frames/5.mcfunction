$data merge entity $(text_display) {transformation: [0.1994f,0.0151f,0f,0.5443f,-0.0151f,0.1994f,0f,0.6032f,0f,0f,0.2f,0.5641f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_1) {transformation: [-1.0187f,0.0038f,0f,0.693f,0.0039f,1f,0f,0.0827f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_2) {transformation: [-1.0937f,0.0038f,0f,0.8311f,0.0041f,1f,0f,0.6662f,0f,0f,-1f,-0.4375f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(stereo) {transformation: [-0.9972f,0.0753f,0f,0.9375f,0.0753f,0.9972f,0f,0f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_1) {transformation: [-0.997f,-0.0466f,0.4101f,-0.5711f,-0.0695f,1.0759f,-0.0466f,0.374f,-0.4069f,-0.0695f,-0.997f,0.2457f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_2) {transformation: [-0.997f,-0.0466f,0.4101f,-0.447f,-0.0695f,1.0759f,-0.0466f,0.8514f,-0.4069f,-0.0695f,-0.997f,0.2745f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_4) {transformation: [-0.9239f,-0.0393f,0.3801f,-0.5474f,-0.0644f,0.9073f,-0.0432f,0.0568f,-0.3771f,-0.0586f,-0.9239f,-0.3385f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_box) {transformation: [-0.9239f,-0.0432f,0.3801f,-0.4946f,-0.0644f,0.997f,-0.0432f,0.0225f,-0.3771f,-0.0644f,-0.9239f,0.0907f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
