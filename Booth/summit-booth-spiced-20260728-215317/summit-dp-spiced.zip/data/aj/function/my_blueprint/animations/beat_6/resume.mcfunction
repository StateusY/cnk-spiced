tag @s add aj.my_blueprint.animation.beat_6.playing
