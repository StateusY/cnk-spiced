$data merge entity $(cable_1) {transformation: [-1.0061f,0.0181f,0f,0.6875f,0.0182f,0.9998f,0f,0.0641f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_2) {transformation: [-1.0562f,0.0126f,0f,0.7813f,0.0133f,0.9999f,0f,0.6563f,0f,0f,-1f,-0.4375f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_1) {transformation: [-1.0372f,-0.0019f,0.4296f,-0.5573f,0f,1.1226f,0.0049f,0.4818f,-0.4296f,0.0045f,-1.0371f,0.2693f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_2) {transformation: [-1.0372f,-0.0019f,0.4296f,-0.4137f,0f,1.1226f,0.0049f,0.9506f,-0.4296f,0.0045f,-1.0371f,0.3309f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_4) {transformation: [-0.9239f,-0.0031f,0.3827f,-0.5437f,0f,1.9f,0.0043f,0.2046f,-0.3827f,0.0076f,-0.9239f,-0.3352f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_box) {transformation: [-0.9239f,-0.0017f,0.3827f,-0.4946f,0f,1f,0.0043f,0.1389f,-0.3827f,0.004f,-0.9239f,0.0907f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
