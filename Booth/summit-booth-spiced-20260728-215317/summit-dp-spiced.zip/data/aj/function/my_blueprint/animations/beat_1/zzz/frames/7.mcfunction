$data merge entity $(text_display) {transformation: [0.1998f,0.0094f,0f,0.5272f,-0.0094f,0.1998f,0f,0.5917f,0f,0f,0.2f,0.5641f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_1) {transformation: [-1.0053f,0.0436f,0f,0.6908f,0.0439f,0.999f,0f,0.0757f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_2) {transformation: [-1.0303f,0.0436f,0f,0.8121f,0.045f,0.999f,0f,0.6628f,0f,0f,-1f,-0.4375f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(stereo) {transformation: [-0.9989f,0.0468f,0f,0.9375f,0.0468f,0.9989f,0f,0f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_1) {transformation: [-0.9846f,-0.0024f,0.4075f,-0.5575f,-0.0036f,1.0656f,-0.0024f,0.3592f,-0.4075f,-0.0036f,-0.9846f,0.2668f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_2) {transformation: [-0.9846f,-0.0024f,0.4075f,-0.4142f,-0.0036f,1.0656f,-0.0024f,0.8285f,-0.4075f,-0.0036f,-0.9846f,0.3249f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_4) {transformation: [-0.924f,-0.0019f,0.3824f,-0.5439f,-0.0034f,0.856f,-0.0022f,0.0775f,-0.3824f,-0.0029f,-0.924f,-0.3357f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_box) {transformation: [-0.924f,-0.0022f,0.3824f,-0.4946f,-0.0034f,1f,-0.0022f,0.015f,-0.3824f,-0.0034f,-0.924f,0.0907f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
