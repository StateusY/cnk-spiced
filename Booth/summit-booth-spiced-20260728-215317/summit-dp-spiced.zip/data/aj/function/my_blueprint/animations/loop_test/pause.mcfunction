tag @s remove aj.my_blueprint.animation.loop_test.playing
