scoreboard players set @s aj.beat_6.frame 0
tag @s add aj.transforms_only
execute at @s run function aj:my_blueprint/animations/beat_6/zzz/zzz/set_frame {frame: 0}
tag @s remove aj.transforms_only
tag @s remove aj.my_blueprint.animation.beat_6.playing
