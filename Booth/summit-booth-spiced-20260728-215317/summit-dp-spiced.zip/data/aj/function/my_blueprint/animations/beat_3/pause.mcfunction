tag @s remove aj.my_blueprint.animation.beat_3.playing
