tag @s add aj.my_blueprint.animation.beat_2.playing
