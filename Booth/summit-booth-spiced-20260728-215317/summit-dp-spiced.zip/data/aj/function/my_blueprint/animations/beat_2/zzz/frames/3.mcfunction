$data merge entity $(text_display) {transformation: [0.2f,0.0019f,0f,0.5053f,-0.0019f,0.2f,0f,0.5759f,0f,0f,0.2f,0.5641f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_1) {transformation: [-1.0159f,0.0744f,0f,0.6881f,0.0758f,0.9972f,0f,0.0664f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_2) {transformation: [-1.091f,0.0712f,0f,0.7873f,0.0778f,0.9975f,0f,0.6577f,0f,0f,-1f,-0.4375f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(stereo) {transformation: [-1f,0.0093f,0f,0.9375f,0.0093f,1f,0f,0f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_1) {transformation: [-1.0639f,0.1394f,0.4397f,-0.5149f,0.0927f,1.1475f,-0.1394f,0.6119f,-0.4519f,-0.0927f,-1.0639f,0.2393f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_2) {transformation: [-1.0639f,0.1394f,0.4397f,-0.3152f,0.0927f,1.1475f,-0.1394f,1.0632f,-0.4519f,-0.0927f,-1.0639f,0.2627f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_4) {transformation: [-0.9175f,0.4448f,0.3792f,-0.5359f,0.08f,3.6612f,-0.1202f,0.285f,-0.3897f,-0.2959f,-0.9175f,-0.3397f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_box) {transformation: [-0.9175f,0.1202f,0.3792f,-0.4946f,0.08f,0.9895f,-0.1202f,0.25f,-0.3897f,-0.08f,-0.9175f,0.0907f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
