tag @s remove aj.my_blueprint.animation.beat_6.playing
