tag @s add aj.my_blueprint.animation.beat_5.playing
