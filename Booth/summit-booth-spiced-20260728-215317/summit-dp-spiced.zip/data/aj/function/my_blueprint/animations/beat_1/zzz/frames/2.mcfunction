$data merge entity $(text_display) {transformation: [0.2f,-0.0022f,0f,0.4938f,0.0022f,0.2f,0f,0.5671f,0f,0f,0.2f,0.5641f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_1) {transformation: [-1.0124f,0.0106f,0f,0.6868f,0.0107f,0.9999f,0f,0.0613f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_2) {transformation: [-1.0624f,0.0106f,0f,0.7741f,0.0113f,0.9999f,0f,0.6545f,0f,0f,-1f,-0.4375f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(stereo) {transformation: [-0.9999f,-0.0109f,0f,0.9375f,-0.0109f,0.9999f,0f,0f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_1) {transformation: [-1.0741f,-0.0597f,0.4423f,-0.574f,-0.089f,1.1582f,-0.0597f,0.5749f,-0.4374f,-0.089f,-1.0741f,0.2415f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_2) {transformation: [-1.0741f,-0.0597f,0.4423f,-0.4537f,-0.089f,1.1582f,-0.0597f,1.0536f,-0.4374f,-0.089f,-1.0741f,0.2644f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_4) {transformation: [-0.9235f,-0.1574f,0.3803f,-0.5477f,-0.0765f,3.0536f,-0.0513f,0.2508f,-0.376f,-0.2345f,-0.9235f,-0.3389f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_box) {transformation: [-0.9235f,-0.0513f,0.3803f,-0.4946f,-0.0765f,0.9957f,-0.0513f,0.2222f,-0.376f,-0.0765f,-0.9235f,0.0907f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
