$data merge entity $(text_display) {transformation: [0.2f,0.0011f,0f,0.5031f,-0.0011f,0.2f,0f,0.5742f,0f,0f,0.2f,0.5641f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_1) {transformation: [-1.0187f,0.0093f,0f,0.6878f,0.0095f,1f,0f,0.0654f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_2) {transformation: [-1.0937f,0.0093f,0f,0.7848f,0.0102f,1f,0f,0.6571f,0f,0f,-1f,-0.4375f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(stereo) {transformation: [-1f,0.0054f,0f,0.9375f,0.0054f,1f,0f,0f,0f,0f,-1f,-0.3125f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_1) {transformation: [-1.0706f,-0.0626f,0.4411f,-0.5749f,-0.0933f,1.1542f,-0.0626f,0.6031f,-0.4356f,-0.0933f,-1.0706f,0.24f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_2) {transformation: [-1.0706f,-0.0626f,0.4411f,-0.456f,-0.0933f,1.1542f,-0.0626f,1.0822f,-0.4356f,-0.0933f,-1.0706f,0.261f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(cable_4) {transformation: [-0.9233f,-0.2214f,0.3804f,-0.5478f,-0.0805f,4.0807f,-0.054f,0.2767f,-0.3757f,-0.3299f,-0.9233f,-0.339f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
$data merge entity $(speaker_box) {transformation: [-0.9233f,-0.054f,0.3804f,-0.4946f,-0.0805f,0.9953f,-0.054f,0.25f,-0.3757f,-0.0805f,-0.9233f,0.0907f,0f,0f,0f,1f],start_interpolation: 0,interpolation_duration: 1}
