execute store result storage animated_java:temp args.id int 1 run scoreboard players get @s aj.id
function animated_java:global/data_manager/read with storage animated_java:temp args
execute if score @s aj.beat_1.frame matches 9.. run scoreboard players set @s aj.beat_1.frame 1
data remove storage animated_java:temp args
execute store result storage animated_java:temp args.frame int 1 run scoreboard players get @s aj.beat_1.frame
execute at @s run function aj:my_blueprint/animations/beat_1/zzz/apply_frame with storage animated_java:temp args
scoreboard players add @s aj.beat_1.frame 1
