kill @e[tag=aj.my_blueprint.entity]
