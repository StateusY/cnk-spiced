execute as @e[type=minecraft:item_display, tag=aj.my_blueprint.root] run function aj:my_blueprint/remove/this
