execute store result storage animated_java:temp args.id int 1 run scoreboard players get @s aj.id
function animated_java:global/data_manager/read with storage animated_java:temp args
execute unless data storage animated_java:temp {entry: {data: {rig_hash: "c98dbb8121143afa90ebd0d04212405de5bd3283089c1e7c3338689ab290eb5d"}}} run function animated_java:global/remove/outdated_rig
function aj:my_blueprint/remove/this/zzz/0 with storage animated_java:temp entry.data.uuids_by_name
function animated_java:global/remove/entity_stack
