data modify entity @s CustomName set value ["", {text: "aj.my_blueprint", color: "#00aced"}, ".", {text: "text_display", color: "light_purple"}, ".", {text: "text_display", color: "gold"}]
function animated_java:global/gu/get_entity_uuid_string
scoreboard players operation @s aj.id = aj.last_id aj.id
