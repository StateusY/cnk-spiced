$function aj:my_blueprint/animations/$(animation)/resume
