execute store result score @s aj.id run scoreboard players add aj.last_id aj.id 1
function animated_java:global/gu/get_entity_uuid_string
data modify storage animated_java:temp args.uuid set from storage animated_java:gu out
execute store result storage animated_java:temp args.id int 1 run scoreboard players get @s aj.id
function animated_java:global/data_manager/create_entry with storage animated_java:temp args
execute store result storage animated_java:temp args.id int 1 run scoreboard players get @s aj.id
function animated_java:global/data_manager/read with storage animated_java:temp args
data modify storage animated_java:temp entry.data.uuids append from storage animated_java:gu out
data modify storage animated_java:temp entry.data.root_uuid set from storage animated_java:gu out
data modify storage animated_java:temp entry.data.blueprint_id set value "aj:my_blueprint"
data modify storage animated_java:temp entry.data.rig_hash set value "c98dbb8121143afa90ebd0d04212405de5bd3283089c1e7c3338689ab290eb5d"
tp @s ~ ~ ~ ~ ~
execute on passengers if entity @s[tag=aj.my_blueprint.node.text_display] run function aj:my_blueprint/zzz/summon/as_node/text_display
data modify storage animated_java:temp entry.data.uuids append from storage animated_java:gu out
data modify storage animated_java:temp entry.data.uuids_by_name.text_display set from storage animated_java:gu out
execute on passengers if entity @s[tag=aj.my_blueprint.node.cable_1] run function aj:my_blueprint/zzz/summon/as_node/cable_1
data modify storage animated_java:temp entry.data.uuids append from storage animated_java:gu out
data modify storage animated_java:temp entry.data.uuids_by_name.cable_1 set from storage animated_java:gu out
execute on passengers if entity @s[tag=aj.my_blueprint.node.cable_2] run function aj:my_blueprint/zzz/summon/as_node/cable_2
data modify storage animated_java:temp entry.data.uuids append from storage animated_java:gu out
data modify storage animated_java:temp entry.data.uuids_by_name.cable_2 set from storage animated_java:gu out
execute on passengers if entity @s[tag=aj.my_blueprint.node.stereo] run function aj:my_blueprint/zzz/summon/as_node/stereo
data modify storage animated_java:temp entry.data.uuids append from storage animated_java:gu out
data modify storage animated_java:temp entry.data.uuids_by_name.stereo set from storage animated_java:gu out
execute on passengers if entity @s[tag=aj.my_blueprint.node.speaker_1] run function aj:my_blueprint/zzz/summon/as_node/speaker_1
data modify storage animated_java:temp entry.data.uuids append from storage animated_java:gu out
data modify storage animated_java:temp entry.data.uuids_by_name.speaker_1 set from storage animated_java:gu out
execute on passengers if entity @s[tag=aj.my_blueprint.node.speaker_2] run function aj:my_blueprint/zzz/summon/as_node/speaker_2
data modify storage animated_java:temp entry.data.uuids append from storage animated_java:gu out
data modify storage animated_java:temp entry.data.uuids_by_name.speaker_2 set from storage animated_java:gu out
execute on passengers if entity @s[tag=aj.my_blueprint.node.cable_4] run function aj:my_blueprint/zzz/summon/as_node/cable_4
data modify storage animated_java:temp entry.data.uuids append from storage animated_java:gu out
data modify storage animated_java:temp entry.data.uuids_by_name.cable_4 set from storage animated_java:gu out
execute on passengers if entity @s[tag=aj.my_blueprint.node.speaker_box] run function aj:my_blueprint/zzz/summon/as_node/speaker_box
data modify storage animated_java:temp entry.data.uuids append from storage animated_java:gu out
data modify storage animated_java:temp entry.data.uuids_by_name.speaker_box set from storage animated_java:gu out
execute on passengers if entity @s[tag=aj.my_blueprint.node.base] run function aj:my_blueprint/zzz/summon/as_node/base
data modify storage animated_java:temp entry.data.uuids append from storage animated_java:gu out
data modify storage animated_java:temp entry.data.uuids_by_name.base set from storage animated_java:gu out
function animated_java:global/data_manager/write with storage animated_java:temp args
function aj:my_blueprint/zzz/set_default_pose
execute if data storage animated_java:temp args.variant run function aj:my_blueprint/zzz/summon/zzz/variant_arg/no_variants_warning
execute if score #success aj.i matches 0 run return fail
execute if data storage animated_java:temp args.animation run function aj:my_blueprint/zzz/summon/animation_arg/process with storage animated_java:temp args
execute if score #success aj.i matches 0 run return fail
execute on passengers run rotate @s ~ ~
data modify entity @s teleport_duration set value 1
execute on passengers run data modify entity @s teleport_duration set value 1
tag @s remove aj.new
execute on passengers run tag @s remove aj.new
