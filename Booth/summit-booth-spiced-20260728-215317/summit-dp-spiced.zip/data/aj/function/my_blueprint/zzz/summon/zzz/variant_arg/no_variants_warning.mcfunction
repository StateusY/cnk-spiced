tellraw @a [{text: "", color: "red"}, [{color: "gray", text: "\n "}, {color: "#00aced", text: "\u1d00\u0274\u026a\u1d0d\u1d00\u1d1b\u1d07\u1d05 \u1d0a\u1d00\u1d20\u1d00"}, {color: "dark_gray", italic: true, text: "\n (aj:my_blueprint)"}, "\n \u2192 "], "\u1d07\u0280\u0280\u1d0f\u0280: ", {text: "No Variants", underlined: true}, "\n\n ", "This Blueprint has no variants to switch between.", "\n"]
function aj:my_blueprint/remove/this/without_on_remove_function
scoreboard players set #success aj.i 0
