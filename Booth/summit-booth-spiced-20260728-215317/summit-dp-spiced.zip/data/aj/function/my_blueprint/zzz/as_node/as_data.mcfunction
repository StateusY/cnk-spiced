$data modify storage animated_java:temp args.uuid set from storage animated_java:temp entry.data.uuids_by_name.$(name)
function aj:my_blueprint/zzz/as_node/execute_as_uuid with storage animated_java:temp args
