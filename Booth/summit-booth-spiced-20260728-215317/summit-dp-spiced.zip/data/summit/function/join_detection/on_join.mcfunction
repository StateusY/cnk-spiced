scoreboard players set @s summit.on_join 0
function #summit:api/on_join
function summit:reset_player
