attribute @s minecraft:camera_distance modifier add summit.camera_distance 1 add_value
attribute @s minecraft:fall_damage_multiplier modifier add summit.fall_damage_multiplier -1 add_multiplied_total
attribute @s minecraft:name_tag_distance modifier add summit.name_tag_distance -24 add_value
attribute @s minecraft:waypoint_receive_range modifier add summit.waypoint_receive_range 0 add_value
