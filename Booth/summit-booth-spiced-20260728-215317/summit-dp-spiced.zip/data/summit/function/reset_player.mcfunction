team leave @s
gamemode adventure @s[tag=!summit.admin, gamemode=!creative]
scoreboard players reset @s summit.below_name
clear @s[tag=!summit.admin] *[!minecraft:custom_data~{summit: {persist: {}}}]
title @s clear
title @s reset
function #summit:api/reset_player
