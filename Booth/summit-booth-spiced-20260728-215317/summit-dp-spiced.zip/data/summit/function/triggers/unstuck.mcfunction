scoreboard players set @s unstuck 0
function summit:reset_player
execute in minecraft:overworld if block ~ -43 ~ minecraft:pink_concrete run return run tp @s @n[tag=summit.safe_location.patched_plateaus]
execute in minecraft:overworld if block ~ -43 ~ minecraft:orange_concrete run return run tp @s @n[tag=summit.safe_location.textured_tropics]
execute in minecraft:overworld if block ~ -43 ~ minecraft:lime_concrete run return run tp @s @n[tag=summit.safe_location.welded_woodlands]
execute in minecraft:overworld if block ~ -43 ~ minecraft:blue_concrete run return run tp @s @n[tag=summit.safe_location.hub]
execute in minecraft:overworld run tp @s @n[tag=summit.safe_location]
