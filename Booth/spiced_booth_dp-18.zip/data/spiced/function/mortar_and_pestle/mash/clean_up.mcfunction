data modify entity @s item.components."minecraft:custom_data".spiced set value {}
tag @s add spiced.finished_mortar_and_pestle
execute on passengers if entity @s[type=minecraft:item_display,tag=spiced.mortar_and_pestle_item] run data modify entity @n[tag=spiced.finished_mortar_and_pestle] item.components."minecraft:custom_data".spiced.last_recipe append from entity @s item
tag @s remove spiced.finished_mortar_and_pestle

particle minecraft:poof ~ ~-0.3 ~ 0.1 0.1 0.1 0 4 normal @a[distance=..10]
playsound entity.item.pickup block @a[distance=..7] ~ ~ ~ 0.6 1
execute on passengers if entity @s[type=minecraft:item_display,tag=spiced.mortar_and_pestle_item] run kill @s
scoreboard players set @s spiced.item_count 0

# execute if data entity @s data.spiced.last_interact_uuid run function spiced:mortar_and_pestle/post_mash/find with entity @s data.spiced