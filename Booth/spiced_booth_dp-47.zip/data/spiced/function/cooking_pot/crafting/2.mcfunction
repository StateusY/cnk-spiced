execute if function spiced:cooking_pot/crafting/generic/meat if score $meat_count spiced.dummy matches 1.. \
        if data storage spiced:temp cooking_pot.Items[{components:{"minecraft:custom_data":{spiced:{ingredient:{type:"water_bottle"}}}}}] \
        if function spiced:cooking_pot/crafting/lock \
        run return run function spiced:cooking_pot/recipes/stock