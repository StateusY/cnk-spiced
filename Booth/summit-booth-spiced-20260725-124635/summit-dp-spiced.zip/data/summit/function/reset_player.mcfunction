team leave @s
gamemode adventure @s[gamemode=!creative]
scoreboard players reset @s summit.below_name
clear @s *[!minecraft:custom_data~{summit: {persist: {}}}]
title @s clear
title @s reset
