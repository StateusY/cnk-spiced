advancement grant @s from summit:booth_exit_root
function #summit.booth:exit
tag @s add summit.battlegrounds.player
title @s actionbar ["", {text: "[Baobab Battlegrounds] ", color: "gold"}, {text: "You have entered the battlegrounds.", color: "green"}]
function summit.inventory_management:save
function summit.battlegrounds:player/action/give_kit
function #summit.battlegrounds:api/player_enter
