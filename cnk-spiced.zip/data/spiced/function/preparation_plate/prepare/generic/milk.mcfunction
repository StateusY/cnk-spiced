scoreboard players set $milk_count cnk.dummy 0

execute if data storage cnk:temp preparation_plate.Items[{components:{"minecraft:custom_data":{cnk:{ingredient:{type:"milk_bottle"}}}}}] run scoreboard players add $milk_count cnk.dummy 1
execute if data storage cnk:temp preparation_plate.Items[{id:"minecraft:milk_bucket"}] run scoreboard players add $milk_count cnk.dummy 1
execute if data storage cnk:temp preparation_plate.Items[{components:{"minecraft:custom_data":{cnk:{pail:{liquid:"milk"}}}}}] run scoreboard players add $milk_count cnk.dummy 1

return 1