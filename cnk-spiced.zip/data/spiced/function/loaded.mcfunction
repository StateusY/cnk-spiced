tellraw @a [{"translate":"spiced.tooltip","font":"cnk:tooltip","color":"white","italic":false},{text:" ","font":"minecraft:default"},{"translate":cnk.loaded,"font":"minecraft:default"}]

scoreboard objectives add spiced.mash_time dummy
scoreboard objectives add spiced.prepare_time dummy
scoreboard objectives add spiced.grind_time dummy
scoreboard objectives add spiced.flaming_cocktail minecraft.used:minecraft.splash_potion