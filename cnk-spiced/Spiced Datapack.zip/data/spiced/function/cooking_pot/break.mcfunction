#------------------------------------------------------------------------------------
# HEY! This file is code from Crop & Kettle by Creature Comforts!
# We have been given permission to utilize it for use at smithed summit by MaybeJake.
# We do NOT claim any legal right or creative license to this file.
#------------------------------------------------------------------------------------

kill @n[type=minecraft:item,nbt={Age:0s,Item:{id:"minecraft:hopper"}},distance=..1]
kill @n[type=minecraft:item,nbt={Age:1s,Item:{id:"minecraft:hopper"}},distance=..1]
function spiced:cooking_pot/drop

playsound minecraft:block.iron.break block @a ~ ~ ~ 1 1

# stop sounds
execute if entity @s[tag=!spiced.stove] run stopsound @a[distance=..6] block spiced:block.cooking_pot.idling
execute if score @s spiced.cook_time matches 1.. if entity @s[tag=!spiced.stove] run stopsound @a[distance=..6] block spiced:block.cooking_pot.cooking

kill @s