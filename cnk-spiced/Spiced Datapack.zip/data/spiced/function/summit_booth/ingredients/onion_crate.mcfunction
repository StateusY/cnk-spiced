playsound minecraft:ui.hud.bubble_pop block @a[distance=..15]
loot give @s loot spiced:food/onion