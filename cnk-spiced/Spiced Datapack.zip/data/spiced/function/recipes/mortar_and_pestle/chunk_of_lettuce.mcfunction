loot spawn ~ ~0.25 ~ loot spiced:food/chunk_of_lettuce

function spiced:mortar_and_pestle/mash/clean_up