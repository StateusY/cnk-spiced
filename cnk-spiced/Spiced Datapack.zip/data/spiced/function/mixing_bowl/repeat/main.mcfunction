#------------------------------------------------------------------------------------
# HEY! This file is code from Crop & Kettle by Creature Comforts!
# We have been given permission to utilize it for use at smithed summit by MaybeJake.
# We do NOT claim any legal right or creative license to this file.
#------------------------------------------------------------------------------------

advancement grant @p[tag=spiced.interact_mixing_bowl,distance=..20] only spiced:visible/remix

data modify storage spiced:temp mixing_bowl.last_recipe set from entity @s item.components."minecraft:custom_data".spiced.last_recipe
data modify storage spiced:temp mixing_bowl.last_recipe[].count set value 1
execute if data storage spiced:temp mixing_bowl.last_recipe[{components:{"minecraft:custom_data":{spiced:{block:{type:"pail"}}}}}] run function spiced:mixing_bowl/repeat/pail
execute store result score $bowl_item_count spiced.dummy run data get storage spiced:temp mixing_bowl.last_recipe

#remove duplicates, increase count
function spiced:mixing_bowl/repeat/compress/main

execute store result score $compress_item_count spiced.dummy run data get storage spiced:temp mixing_bowl.compress

#ensure items exist
function spiced:mixing_bowl/repeat/check/main

execute if score $items_found spiced.dummy matches 0 run return fail

#all items found, GET EM OUTTA HERE
function spiced:mixing_bowl/repeat/remove/main

#start inserting items
execute unless score $bowl_item_count spiced.dummy matches 1.. run return fail
data modify storage spiced:temp mixing_bowl.input set from storage spiced:temp mixing_bowl.last_recipe[0]
function spiced:mixing_bowl/repeat/insert

execute unless score $bowl_item_count spiced.dummy matches 2.. run return run function spiced:mixing_bowl/mix/main
data modify storage spiced:temp mixing_bowl.input set from storage spiced:temp mixing_bowl.last_recipe[1]
function spiced:mixing_bowl/repeat/insert

execute unless score $bowl_item_count spiced.dummy matches 3.. run return run function spiced:mixing_bowl/mix/main
data modify storage spiced:temp mixing_bowl.input set from storage spiced:temp mixing_bowl.last_recipe[2]
function spiced:mixing_bowl/repeat/insert

execute unless score $bowl_item_count spiced.dummy matches 4.. run return run function spiced:mixing_bowl/mix/main
data modify storage spiced:temp mixing_bowl.input set from storage spiced:temp mixing_bowl.last_recipe[3]
function spiced:mixing_bowl/repeat/insert

function spiced:mixing_bowl/mix/main