execute store result storage spiced:temp register.page_number int 1 run scoreboard players get $global_cookbook_page spiced.dummy

data modify storage spiced:temp register.tool set value "spiced.cooking_pot"
data modify storage spiced:temp register.page_name set value "item.spiced.huntsman_pie_incomplete_1"
data modify storage spiced:temp register.recipe_icon_font set value "spiced:icons"

data modify storage spiced:temp register.ingredients set value [ \
    {key:"item.spiced.sliced_celery", font:"spiced:icons"}, \
    {key:"item.spiced.stock", font:"spiced:icons"}, \
    {key:"item.spiced.cooking_oil", font:"spiced:icons"}, \
    {key:"item.spiced.sliced_onion", font:"spiced:icons"}, \
    {key:"item.spiced.ground_cinnamon", font:"spiced:icons"}, \
]

data modify storage spiced:temp register.source set value {key:"spiced.source", font:"spiced:icons"}

function spiced:cookbook/pages/page_gen/register